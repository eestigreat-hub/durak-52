"use client";
import {useState,useEffect,useRef} from 'react';
import {ArrowLeft,Check,Copy,Volume2,VolumeX,X,HelpCircle} from 'lucide-react';
import {createGame,act,botAction,legalActions,viewFor} from '../lib/game.mjs';
import {actionForCard,collectionFor} from '../lib/interaction.mjs';
import {createPeerGame} from '../lib/peer-game.mjs';
import {asset} from '../lib/asset.mjs';
import Card,{CardType,suitNames,rank} from './card';

type Action={type:string;card?:string;pair?:number};
const names:Record<string,string>={throw:'Подкидной',transfer:'Переводной'};

export default function Home(){
 const [mode,setMode]=useState('bot'),[variant,setVariant]=useState('throw');
 const [game,setGame]=useState<any>(null),[online,setOnline]=useState<any>(null),[room,setRoom]=useState('');
 const [busy,setBusy]=useState(false),[modal,setModal]=useState(''),[error,setError]=useState('');
 const [copied,setCopied]=useState(false),[sound,setSound]=useState(false),[connecting,setConnecting]=useState(false);
 const [collection,setCollection]=useState<{up:boolean;cards:CardType[];id:number}|null>(null);
 const previousView=useRef<any>(null);
 const token=useRef(''),audio=useRef<HTMLAudioElement|null>(null),operation=useRef(false),soundRef=useRef(false);
 const peerGame=useRef<any>(null),connectionAttempt=useRef<AbortController|null>(null);
 const view:any=online||(game?viewFor(game,0):null),playing=!!view&&!view.waiting;
 const actions:Action[]=view?.actions||[],yourAttack=!!view&&view.attacker===view.seat;
 const can=(type:string)=>actions.some(a=>a.type===type);
 const tableSignature=view?.table?.map((p:any)=>p.attack.id+':'+(p.defense?.id||'')).join('|');
 useEffect(()=>{
   if(view){const event=collectionFor(previousView.current,view);if(event)setCollection({...event,id:Date.now()});}
   previousView.current=view;
 },[view?.round,view?.taking,tableSignature,view?.collection?.round]);
 useEffect(()=>{if(!collection)return;const timer=setTimeout(()=>setCollection(null),1400);return ()=>clearTimeout(timer);},[collection]);

 useEffect(()=>{
   let saved=sessionStorage.getItem('trefy-peer-player');
   if(!saved){saved=crypto.randomUUID();sessionStorage.setItem('trefy-peer-player',saved);}
   token.current=saved;
   const enabled=localStorage.getItem('trefy-sound')!=='off';setSound(enabled);soundRef.current=enabled;
   audio.current=new Audio(asset('audio/card-slide.ogg'));audio.current.preload='auto';audio.current.volume=.2;
   const id=new URLSearchParams(location.search).get('room');if(id){setMode('friend');join(id);}
   return ()=>{audio.current?.pause();connectionAttempt.current?.abort();peerGame.current?.destroy();};
 },[]);
 function cardSound(){if(!soundRef.current||!audio.current)return;const a=audio.current.cloneNode() as HTMLAudioElement;a.volume=.2;a.play().catch(()=>{});}
 function toggleSound(){const next=!sound;setSound(next);soundRef.current=next;localStorage.setItem('trefy-sound',next?'on':'off');if(next)cardSound();}
 function accept(data:any){setOnline((old:any)=>!old||data.revision>=old.revision?data:old);setVariant(data.variant);setConnecting(false);}
 async function connectRoom(id?:string){
   connectionAttempt.current?.abort();peerGame.current?.destroy();
   const controller=new AbortController();connectionAttempt.current=controller;
   setBusy(true);setError('');setConnecting(false);setOnline(null);
   let saved;try{if(id)saved=JSON.parse(sessionStorage.getItem(`trefy-host-${id}`)||'null');}catch{}
   try{
     const client=await createPeerGame({token:token.current,room:id,variant,saved,signal:controller.signal,
       onView:(v:any)=>{if(!controller.signal.aborted)accept(v);},
       onStatus:(connected:boolean)=>{if(!controller.signal.aborted)setConnecting(!connected);},
       onSave:(s:any)=>{try{sessionStorage.setItem(`trefy-host-${s.id}`,JSON.stringify(s));}catch{}},
       onError:(message:string)=>{if(!controller.signal.aborted)setError(message);}
     });
     if(controller.signal.aborted){client.destroy();return;}
     peerGame.current=client;setRoom(client.id);history.replaceState(null,'',`?room=${encodeURIComponent(client.id)}`);
   }catch(e){if(!controller.signal.aborted){setOnline(null);setRoom('');setError((e as Error).message);}}
   finally{if(!controller.signal.aborted)setBusy(false);}
 }
 async function join(id:string){if(!/^trefy-[a-zA-Z0-9-]{20,64}$/.test(id)){setError('Приглашение устарело или повреждено. Попросите друга создать новый стол.');return;}await connectRoom(id);}
 useEffect(()=>{
   if(!game||game.winner!==null)return;
   const own=legalActions(game,0),bot=legalActions(game,1);if(!bot.length)return;
   if(game.attacker===1&&own.some((a:Action)=>a.type==='defend'||a.type==='take'))return;
   const timer=setTimeout(()=>{const a=botAction(game,1);if(a){setGame(act(game,1,a));cardSound();}},650);
   return ()=>clearTimeout(timer);
 },[game]);
 useEffect(()=>{if(error){const t=setTimeout(()=>setError(''),8000);return ()=>clearTimeout(t);}},[error]);
 const result=playing&&view.winner!==null,dialogOpen=!!modal||result;
 useEffect(()=>{
   if(!dialogOpen)return;const before=document.activeElement as HTMLElement|null;
   const dialog=document.querySelector<HTMLElement>('[role="dialog"]');
   const focusable=()=>Array.from(dialog?.querySelectorAll<HTMLElement>('button:not(:disabled),a[href],input')||[]);
   focusable()[0]?.focus();
   const key=(e:KeyboardEvent)=>{if(e.key==='Escape'&&modal){setModal('');e.preventDefault();}if(e.key==='Tab'){const list=focusable(),first=list[0],last=list[list.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}};
   document.addEventListener('keydown',key);return ()=>{document.removeEventListener('keydown',key);before?.focus();};
 },[dialogOpen,modal]);
 async function start(){
   setError('');if(mode==='bot'){history.replaceState(null,'',location.pathname);setOnline(null);setGame(createGame(variant));cardSound();return;}
   await connectRoom();
 }
 async function move(action:Action){
   if(busy||operation.current||connecting)return;setError('');
   try{if(room){operation.current=true;setBusy(true);accept(await peerGame.current.move({...action,revision:view.revision}));}else setGame(act(game,0,action));cardSound();}
   catch(e){setError((e as Error).message);}
   finally{operation.current=false;setBusy(false);}
 }
 function playCard(card:string,pair?:number){if(busy||connecting)return;const action=actionForCard(actions,card,pair);if(action)move(action);}
 function leave(){connectionAttempt.current?.abort();peerGame.current?.destroy();peerGame.current=null;setRoom('');setOnline(null);setGame(null);setModal('');setCollection(null);previousView.current=null;setConnecting(false);history.replaceState(null,'',location.pathname);}
 const invite=()=>`${location.origin}${location.pathname}?room=${encodeURIComponent(room)}`;
 async function copy(){try{await navigator.clipboard.writeText(invite());setCopied(true);setTimeout(()=>setCopied(false),2500);}catch{setError('Выделите ссылку и скопируйте её вручную.');}}
 const hand:CardType[]=[...(view?.hand||[])].sort((a,b)=>(a.suit===view?.trump.suit?1:0)-(b.suit===view?.trump.suit?1:0)||a.suit.localeCompare(b.suit)||a.rank-b.rank);
 const maxBacks=Math.min(view?.opponentCount||0,16);

 return <main className={playing?'app playing':'app'}>
   {!playing&&!room&&<section className="setup" aria-label="Настройка игры">
     <div className="choice-group" aria-label="Соперник">
       <button className={mode==='friend'?'choice active':'choice'} onClick={()=>setMode('friend')} aria-pressed={mode==='friend'}>Играть с другом</button>
       <button className={mode==='bot'?'choice active':'choice'} onClick={()=>setMode('bot')} aria-pressed={mode==='bot'}>Играть с компьютером</button>
     </div>
     <div className="choice-group" aria-label="Правила">
       {['throw','transfer'].map(v=><button key={v} className={variant===v?'choice active':'choice'} onClick={()=>setVariant(v)} aria-pressed={variant===v}>{names[v]}</button>)}
     </div>
     <button className="primary start" onClick={start} disabled={busy}>{busy?'Подключение…':mode==='bot'?'Играть':'Создать комнату'}</button>
     <div className="setup-tools"><button className="plain" onClick={()=>setModal('rules')}>Правила</button><button className="icon" onClick={toggleSound} aria-label={sound?'Выключить звук':'Включить звук'}>{sound?<Volume2 size={19}/>:<VolumeX size={19}/>}</button></div>
   </section>}

   {room&&view?.waiting&&<section className="waiting">
     <h1>Пригласите друга</h1>
     <div className="invite"><input aria-label="Ссылка для приглашения" readOnly value={typeof location!=='undefined'?invite():''} onFocus={e=>e.target.select()}/><button className="primary" onClick={copy}>{copied?<Check size={18}/>:<Copy size={18}/>} {copied?'Скопировано':'Копировать'}</button></div>
     <p>{connecting?'Связь потеряна. Переподключаемся…':'Ожидание соперника · оставьте вкладку открытой'}</p>
     <button className="plain" onClick={()=>setModal('leave')}>Назад</button>
   </section>}

   {playing&&<section className="game" aria-label="Игровой стол">
     <div className="toolbar"><button className="icon" onClick={()=>setModal('leave')} aria-label="Покинуть стол"><ArrowLeft size={20}/></button><span>{names[view.variant]}</span><div><button className="icon" onClick={()=>setModal('rules')} aria-label="Правила"><HelpCircle size={19}/></button><button className="icon" onClick={toggleSound} aria-label={sound?'Выключить звук':'Включить звук'}>{sound?<Volume2 size={19}/>:<VolumeX size={19}/>}</button></div></div>
     <div className="opponent" aria-label={`У соперника ${view.opponentCount} карт`}><div className="opponent-hand" style={{'--backs':maxBacks} as React.CSSProperties}>{Array.from({length:maxBacks},(_,i)=><Card key={i} back/>)}</div>{view.opponentCount>16&&<span className="overflow-count">{view.opponentCount}</span>}</div>
     <div className="table">
       <div className="stock" aria-label={`В колоде ${view.deckCount} карт. Козырь ${suitNames[view.trump.suit]}`}>
         {view.deckCount>0?<div className="stock-cards"><div className={view.deckCount>1?'trump':'last-trump'}><Card card={view.trump}/></div>{view.deckCount>1&&<Card back/>}</div>:<div className="empty-stock"/>}
         <span className="stock-count">{view.deckCount}</span>
       </div>
       <div className="battlefield" onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();playCard(e.dataTransfer.getData('text/plain'));}}>
         {view.table.map((p:any,i:number)=><div key={`${view.round}-${p.attack.id}`} className="card-pair" onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();e.stopPropagation();playCard(e.dataTransfer.getData('text/plain'),i);}} aria-label={`Атака ${rank(p.attack.rank)} ${suitNames[p.attack.suit]}${p.defense?', отбита':''}`}><Card card={p.attack}/>{p.defense&&<div className="defense"><Card card={p.defense}/></div>}</div>)}
       </div>
       <div className="discard" aria-label={`В отбое ${view.discardCount} карт`}>{view.discardCount>0&&<><div className="discard-shape"/><span>{view.discardCount}</span></>}</div>
       {collection&&<div key={collection.id} className={`collect-cards ${collection.up?'collect-up':'collect-down'}`} aria-hidden="true">{collection.cards.map((c,i)=><div className="collect-card" key={c.id} style={{'--offset':`${(i-(collection.cards.length-1)/2)*8}px`,'--delay':`${i*.025}s`} as React.CSSProperties}><Card card={c}/></div>)}</div>}
     </div>
     <div className="own-hand-scroll"><div className="own-hand">{hand.map(c=><Card key={c.id} card={c} onClick={()=>playCard(c.id)} draggable/>)}</div></div>
     <div className="game-action"><button className="primary" disabled={busy||connecting||!can(yourAttack?'finish':'take')} onClick={()=>move({type:yourAttack?'finish':'take'})}>{yourAttack?'Бито':'Взять'}</button></div>
     {(view.taking||collection)&&<div className={`take-notice ${(view.taking?1-view.attacker!==view.seat:collection?.up)?'notice-up':'notice-down'}`} role="status">{(view.taking?1-view.attacker===view.seat:!collection?.up)?'Вы берёте':room?'Соперник берёт':'Компьютер берёт'}</div>}
     {connecting&&<div className="connection-error" role="status">Нет связи с соперником. Переподключаемся…</div>}
   </section>}

   {error&&<div className="toast" role="alert"><span>{error}</span><button className="icon" onClick={()=>setError('')} aria-label="Закрыть сообщение"><X size={18}/></button></div>}
   {dialogOpen&&<div className="shade" onClick={()=>setModal('')}><section className="dialog" role="dialog" aria-modal="true" aria-label={modal==='rules'?'Правила':modal==='leave'?'Покинуть стол':'Партия завершена'} onClick={e=>e.stopPropagation()}>
     {modal&&<button className="icon close" onClick={()=>setModal('')} aria-label="Закрыть"><X size={20}/></button>}
     {modal==='rules'?<><h2>Правила</h2><p>52 карты без джокеров. По шесть каждому. Первым ходит обладатель младшего козыря.</p><p>Нажмите карту, чтобы сыграть её. При защите она отобьёт первую подходящую карту на столе. Можно перетащить карту на конкретную атаку. Неподходящий ход ничего не меняет.</p><p>Старшая карта той же масти бьёт младшую. Козырь бьёт любую другую масть. Подкидываются достоинства карт на столе, не больше шести и числа карт у защищающегося в начале хода.</p><p>В переводном нажатие на карту того же достоинства переводит атаку до первого отбоя, если сопернику хватает карт. Чтобы вместо перевода отбиться этой картой, перетащите её на нужную атаку.</p><p>«Взять» — забрать карты. «Бито» — завершить ход, в том числе после взятия соперником. Добирает сначала атакующий, козырь — последний. После конца колоды первым избавьтесь от карт.</p><p className="credits">Vector Playing Cards 3.0 · Copyright 2011, 2019 Chris Aguilar · <a href="https://totalnonsense.com/open-source-vector-playing-cards/" target="_blank" rel="noreferrer">Источник</a> · <a href={asset('cards/vector/LICENSE.txt')}>LGPL 3.0</a>. Рубашка: David Bellot / SVG-cards, <a href={asset('cards/LICENSE.txt')}>LGPL 2.1</a>. Звук: Kenney, CC0.</p><button className="primary full" onClick={()=>setModal('')}>Закрыть</button></>:modal==='leave'?<><h2>Покинуть стол?</h2><p>{room?'Можно вернуться по ссылке с этого устройства.':'Текущая партия не сохранится.'}</p><div className="dialog-actions"><button className="secondary" onClick={()=>setModal('')}>Продолжить</button><button className="primary" onClick={leave}>Выйти</button></div></>:<><h2>{view.winner==='draw'?'Ничья':view.winner===view.seat?'Вы выиграли':'Вы проиграли'}</h2><button className="primary full" disabled={busy||!!(room&&view.rematch?.[view.seat])} onClick={()=>room?move({type:'rematch'}):setGame(createGame(variant))}>{room&&view.rematch?.[view.seat]?'Ожидание соперника':'Играть ещё'}</button><button className="plain full" onClick={leave}>В меню</button></>}
   </section></div>}
 </main>;
}
