import {asset} from '../lib/asset.mjs';
export type CardType={id:string;rank:number;suit:string};
export const suits:Record<string,string>={clubs:'♣',diamonds:'♦',hearts:'♥',spades:'♠'};
export const suitNames:Record<string,string>={clubs:'треф',diamonds:'бубен',hearts:'червей',spades:'пик'};
export const rank=(r:number)=>({11:'J',12:'Q',13:'K',14:'A'} as Record<number,string>)[r]||r;
export default function Card({card,back=false,onClick,style,draggable=false}:{card?:CardType;back?:boolean;onClick?:()=>void;style?:React.CSSProperties;draggable?:boolean}){
 const face=card?`${card.suit[0]}${String(card.rank===14?1:card.rank).padStart(2,'0')}.svg`:'back.svg';
 const content=<img className="card-image" src={asset(`cards/vector/${back?'back.svg':face}`)} alt="" draggable={false} decoding="async"/>;
 const cls=`playing-card ${back?'card-back':''}`;
 return onClick?<button className={cls} style={style} onClick={onClick} draggable={draggable} onDragStart={e=>{if(card){e.dataTransfer.setData('text/plain',card.id);e.dataTransfer.effectAllowed='move';}}} aria-label={`${rank(card!.rank)} ${suitNames[card!.suit]}`}>{content}</button>:<div className={cls} style={style} aria-hidden="true">{content}</div>;
}
