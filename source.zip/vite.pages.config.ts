import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';

// Independent of Workers/D1, works at both username.github.io and /repository/.
export default defineConfig({
 plugins:[react()],base:'./',build:{outDir:'out'},
 server:{host:'127.0.0.1',port:5183,strictPort:true},
 preview:{host:'127.0.0.1',port:5183,strictPort:true}
});
