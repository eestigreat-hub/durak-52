import {mkdir,readFile,writeFile,readdir,copyFile} from 'node:fs/promises';
import path from 'node:path';

// GitHub's browser picker accepts individual files. Keep this publishable
// directory flat and below its 100-file upload limit, without local state.
const root=process.cwd(),out=path.join(root,'out'),stage=path.join(root,'outputs/github-upload');
await mkdir(stage,{recursive:true});
const copy=(from,to)=>copyFile(path.join(out,from),path.join(stage,to||path.basename(from)));
let html=await readFile(path.join(out,'index.html'),'utf8');
await writeFile(path.join(stage,'index.html'),html.replaceAll('./assets/','./'));
await writeFile(path.join(stage,'.nojekyll'),'');
const rewrite=text=>text.replaceAll('cards/vector/LICENSE.txt','LICENSE-cards-LGPL3.txt').replaceAll('cards/LICENSE.txt','LICENSE-back-LGPL2.txt').replaceAll('cards/vector/','').replaceAll('audio/card-slide.ogg','card-slide.ogg').replaceAll('../textures/felt.svg','./felt.svg');
for(const name of await readdir(path.join(out,'assets'))){
 const data=await readFile(path.join(out,'assets',name),'utf8');
 await writeFile(path.join(stage,name),rewrite(data));
}
for(const name of await readdir(path.join(out,'cards/vector')))if(/^(?:[cdhs](?:0[1-9]|1[0-3])|back)\.svg$/.test(name))await copy(`cards/vector/${name}`);
await copy('cards/vector/LICENSE.txt','LICENSE-cards-LGPL3.txt');
await copy('cards/vector/CREDITS.txt','CREDITS-cards.txt');
await copy('cards/LICENSE.txt','LICENSE-back-LGPL2.txt');
await copy('cards/svg-cards.svg','SOURCE-card-back.svg');
await copy('cards/CREDITS.txt','CREDITS-card-back.txt');
await copy('audio/card-slide.ogg');
await copy('audio/CREDITS.txt','CREDITS-audio.txt');
await copy('textures/felt.svg');
await writeFile(path.join(stage,'README.md'),`# Дурак — 52 карты\n\nПодкидной и переводной дурак. Игра с компьютером или другом по ссылке.\n\n[Открыть игру](https://eestigreat-hub.github.io/durak-52/)\n\nДля игры с другом создатель стола должен оставить вкладку открытой. Ходы зашифрованы и передаются через бесплатные публичные ретрансляторы. Аккаунты и платные ключи не нужны. Доступность внешних сервисов может меняться.\n\nГотовая сборка размещена в корне. Исходники, тесты, оригинальные SVG и скрипт подготовки загрузки — в source.zip. После распаковки: Node.js 22.13+, npm install, npm run dev. Сборка: npm run build.\n\nКарты: Vector Playing Cards 3.0, Chris Aguilar, LGPL 3.0. Рубашка: David Bellot / SVG-cards, LGPL 2.1. Звук Kenney, CC0. Авторство и лицензии доступны в правилах игры и файлах CREDITS / LICENSE.\n`);
console.log(`Browser upload directory: ${stage}`);
